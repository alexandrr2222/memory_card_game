export function shuffle<T>(array: Array<T>) {
  const shuffledArray = [...array];
  for (let i = shuffledArray.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    const k = shuffledArray[i];
    shuffledArray[i] = shuffledArray[j];
    shuffledArray[j] = k;
  }
  return shuffledArray;
}
